﻿namespace NEW_BALL_GAME2
{
    public class EnChar : BaseElement
    {
        public EnChar()
        {
            Output = Properties.Resources.EnChar;
        }
    }
}