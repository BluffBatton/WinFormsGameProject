﻿namespace NEW_BALL_GAME2
{
    public class Wall : BaseElement
    {
        public Wall()
        {
            Output = Properties.Resources.Wall;
        }
    }
}
