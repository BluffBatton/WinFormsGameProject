﻿namespace NEW_BALL_GAME2
{
    public class ShieldLeft : BaseElement
    {
        public ShieldLeft()
        {
            Output = Properties.Resources.ShieldLeft;
        }
    }
}
