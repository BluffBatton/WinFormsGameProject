﻿namespace NEW_BALL_GAME2
{
    public abstract class BaseElement
    {
        public Image? Output;
    }
}
