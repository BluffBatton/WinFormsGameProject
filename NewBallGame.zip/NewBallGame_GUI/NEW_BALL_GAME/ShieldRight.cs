﻿namespace NEW_BALL_GAME2
{
    public class ShieldRight : BaseElement
    {
        public ShieldRight()
        {
            Output = Properties.Resources.ShieldRight;
        }
    }
}
