﻿namespace NEW_BALL_GAME2
{
    public class Space : BaseElement
    {
        public Space()
        {
            Output = Properties.Resources.Space;
        }
    }
}
